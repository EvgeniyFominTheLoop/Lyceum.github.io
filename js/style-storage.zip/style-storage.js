//Created by Ken

$(function(){
  var localStorageStyle = JSON.parse(localStorage.getItem('style')) || {} ; //это он лезет в твой ЛС и смотрит есть ли там что-то по ключу стайл
  if(localStorageStyle != {}){ //если нет то задаёт просто пустой объект localStorageStyle, если есть то там будет объект с ключами айдишников
    for(var el in localStorageStyle){ //потом делает обход по всем ключам (проверка на наличие класа не нужна, он не добавит такой же если есть)
      var elId = $('#'+el); //в каждой итерации делает промежуточные переменные элИД и элКласс
      var elClass = localStorageStyle[el];
      if(!elId.hasClass(elClass)){ // смотрит, если нет у этого промежуточного айдишника такого класса то добавит его
        elId.addClass(elClass);
      }
    }
  }
  $('a.bg1').on('click', function(){ 
    $('#menu-top').removeClass('bg2', 'bg3', 'bg4', 'bg5', 'bg6', 'bg7', 'bg8', 'bg9');
    $('#menu-top').addClass('bg1'); //дальше функция запила стилей на случай еси есть что-то в ЛС
    localStorageStyle['menu-top'] = 'bg1';
    localStorage.setItem('style', JSON.stringify(localStorageStyle)); //сначала перегоняет её в строку, сохраняет целый объект стилей под ключем стайл
  });
  $('a.bg2').on('click', function(){
    $('#menu-top').removeClass('bg1', 'bg3', 'bg4', 'bg5', 'bg6', 'bg7', 'bg8', 'bg9');
    $('#menu-top').addClass('bg2');
    localStorageStyle['menu-top'] = 'bg2';
    localStorage.setItem('style', JSON.stringify(localStorageStyle));
  });
  $('a.bg3').on('click', function(){
    $('#menu-top').removeClass('bg2', 'bg1', 'bg4', 'bg5', 'bg6', 'bg7', 'bg8', 'bg9');
    $('#menu-top').addClass('bg3');
    localStorageStyle['menu-top'] = 'bg3';
    localStorage.setItem('style', JSON.stringify(localStorageStyle)); 
  });

});




// проверяет что это не пустой оъект